﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace CalculoTrimestral
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string result = File.ReadAllText("Consume.txt");
            StringReader reader = new StringReader(result);

            reader.ReadLine();

            List<Data> values = new List<Data>();

            while(true)
            {
                string line = reader.ReadLine();

                if (line == null)
                    break;

                string dateString    = line.Split(';')[0];
                string consumeString = line.Split(';')[2];
                string returnString  = line.Split(';')[3];

                int year  = int.Parse(dateString.Substring(dateString.Length-4));
                //int month = int.Parse(dateString.Substring(dateString.IndexOf("/") + 1, 2));
                int month = int.Parse(dateString.Split('/')[1]);
                int day   = int.Parse(dateString.Split('/')[0]);

                float consumeValue;
                float returnValue;

                if (float.TryParse(consumeString, out consumeValue) 
                    && float.TryParse(returnString, out returnValue))
                    values.Add(new Data
                    {
                        Date = new DateTime(year, month, day),
                        Consume = consumeValue - returnValue
                    });
            }

            var groupByDay =
                (from date
                in values
                 group date.Consume by date.Date into daysGroup
                 select new
                 {
                     Date = daysGroup.Key,
                     ConsumeAvg = daysGroup.ToList().Average(),
                     ConsumeSum = daysGroup.ToList().Sum(),
                     ConsumeCount = daysGroup.ToList().Count()
                 });

            int i = 0;
            var groupByMonth =
                (from date
                in values
                 group date.Consume by date.Date.ToString("yyyyMM") into daysGroup
                 select new
                 {
                     Count        = ++i,
                     Date         = daysGroup.Key,
                     ConsumeAvg   = daysGroup.ToList().Average(),
                     ConsumeSum   = daysGroup.ToList().Sum(),
                     ConsumeCount = daysGroup.ToList().Count()
            }).ToArray();

            groupByMonth.ToList().ForEach(e => Console.WriteLine("{0} {1}",e.Count,e.Date));

            /*float trimestre1 = groupByMonth.ToList().
                               Where(e => e.Count == 1 || e.Count == 2 || e.Count == 3).
                               ToList().Average(e=>e.ConsumeAvg);
            
            float trimestre2 = (from value in groupByMonth 
                                where value.Count >= 4 && value.Count<= 6 
                                select value).ToList().Average(e => e.ConsumeAvg);;
            
            */

            Dictionary<int, float> results = new Dictionary<int, float>();

            int a = 1;
            int b = 3;

            for (i = 1; i <= (groupByMonth.ToList().Count / 3); i++)
            {
                results.Add(i,

                            (from value in groupByMonth
                             where value.Count >= a && value.Count <= b
                             select value).ToList().Average(e => e.ConsumeAvg)
                           );
                a += 3;
                b += 3;
            }

            StringBuilder builder = new StringBuilder();
            results.ToList().ForEach(e =>
                builder.AppendLine(String.Format("{0},{1}",
                                                 e.Key, e.Value))
                                    );
            File.WriteAllText("result.csv", builder.ToString());

                                     
            /*Dictionary<int, float> results = new Dictionary<int, float>();

            float total = 0.0f;
            for (int i = 0; i < groupByMonth.ToList().Count; i++)
            {
                if(i%3 == 0)
                    

            }*/


        }
    }
}
