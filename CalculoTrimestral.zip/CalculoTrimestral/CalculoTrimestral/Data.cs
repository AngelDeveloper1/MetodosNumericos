﻿using System;
namespace CalculoTrimestral
{
    public class Data
    {
        public DateTime Date    { get; set; }
        public float Consume    { get; set; }
    }
}
